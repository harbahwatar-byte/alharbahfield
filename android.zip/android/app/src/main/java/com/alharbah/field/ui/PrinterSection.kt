package com.alharbah.field.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.alharbah.field.data.Prefs
import com.alharbah.field.print.PrinterService

/** قسم الطابعة في الإعدادات: اختيار طابعة مقترنة، وعرض الورق 58 أو 80 ملم. */
@Composable
fun PrinterSection(prefs: Prefs) {
    val context = LocalContext.current
    var showList by remember { mutableStateOf(false) }
    var printers by remember { mutableStateOf<List<Pair<String, String>>>(emptyList()) }
    var message by remember { mutableStateOf<String?>(null) }
    var paper by remember { mutableStateOf(prefs.paperWidthMm) }
    var chosen by remember { mutableStateOf(prefs.printerName ?: "لم تُختر طابعة") }

    fun openList() {
        try {
            printers = PrinterService.pairedPrinters()
            showList = true
            if (printers.isEmpty()) message = "لا توجد طابعات مقترنة. اقرن الطابعة من إعدادات البلوتوث في الهاتف أولاً."
        } catch (e: SecurityException) {
            message = "امنح الهاتف إذن البلوتوث ثم أعد المحاولة."
        }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openList() else message = "إذن البلوتوث مطلوب لعرض الطابعات."
    }

    Column(verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp)) {
        Text("الطابعة الحرارية: $chosen")
        OutlinedButton(
            onClick = {
                if (Build.VERSION.SDK_INT >= 31 &&
                    ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED
                ) {
                    permLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
                } else {
                    openList()
                }
            },
            modifier = Modifier.fillMaxWidth(),
        ) { Text("اختيار الطابعة (بلوتوث)") }

        Row {
            Button(onClick = { paper = 58; prefs.paperWidthMm = 58 }) { Text("ورق 58 ملم") }
            Button(onClick = { paper = 80; prefs.paperWidthMm = 80 }, modifier = Modifier.padding(start = 8.dp)) { Text("ورق 80 ملم") }
        }
        Text("عرض الورق المختار: $paper ملم")
        message?.let { Text(it) }
    }

    if (showList) {
        AlertDialog(
            onDismissRequest = { showList = false },
            title = { Text("اختر الطابعة") },
            text = {
                Column {
                    printers.forEach { (name, address) ->
                        TextButton(onClick = {
                            prefs.printerAddress = address
                            prefs.printerName = name
                            chosen = name
                            showList = false
                        }) { Text(name) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showList = false }) { Text("إغلاق") } },
        )
    }
}

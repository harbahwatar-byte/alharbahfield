package com.alharbah.field.ocr

import androidx.annotation.OptIn
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

/** استخراج قراءة العداد (أرقام) من نص مُتعرَّف عليه. */
object MeterOcr {

    /** يحوّل الأرقام العربية-الهندية إلى لاتينية، ثم يختار أطول مجموعة أرقام معقولة (3 إلى 9 أرقام). */
    fun extract(text: String): String? {
        val normalized = text.map { ch ->
            if (ch in '\u0660'..'\u0669') ('0' + (ch - '\u0660')) else ch
        }.joinToString("")
        val groups = Regex("\\d{3,9}").findAll(normalized).map { it.value }.toList()
        return groups.maxByOrNull { it.length }
    }
}

/** محلل صور الكاميرا: يقرأ كل نحو 700 ملّي ثانية ويبلّغ بالأرقام المكتشفة. */
class DigitAnalyzer(private val onDigits: (String) -> Unit) : ImageAnalysis.Analyzer {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var busy = false
    private var lastRun = 0L

    @OptIn(ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) {
        val now = System.currentTimeMillis()
        val media = imageProxy.image
        if (busy || media == null || now - lastRun < 700) {
            imageProxy.close()
            return
        }
        lastRun = now
        busy = true
        val input = InputImage.fromMediaImage(media, imageProxy.imageInfo.rotationDegrees)
        recognizer.process(input)
            .addOnSuccessListener { result -> MeterOcr.extract(result.text)?.let(onDigits) }
            .addOnCompleteListener {
                busy = false
                imageProxy.close()
            }
    }
}

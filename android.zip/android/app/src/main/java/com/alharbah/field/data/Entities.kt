package com.alharbah.field.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/** نسخة محلية من مشترك. تُعبّأ من خادم اللابتوب ويعاد تعبئتها عند كل مزامنة. */
@Entity(tableName = "subscribers")
data class SubscriberEntity(
    @PrimaryKey val subscriberId: Int,
    val fullName: String,
    val meterNumber: String?,
    val address: String?,
    val phone: String?,
    val routeId: Int?,
    val balance: Double,
    val previousReading: Double,
)

/**
 * قراءة ميدانية محلية. تبقى PENDING حتى ترفعها المزامنة فتصبح SENT أو REJECTED.
 * لا تُحذف القراءات من الجهاز قبل أن يؤكد الخادم حفظها.
 */
@Entity(tableName = "readings")
data class ReadingEntity(
    @PrimaryKey(autoGenerate = true) val localId: Long = 0,
    val subscriberId: Int,
    val previousReading: Double,
    val currentReading: Double,
    val readingDate: String,
    val collectorUserId: Int?,
    val status: String = STATUS_PENDING,
    val message: String? = null,
    val serverReadingId: Int? = null,
    val createdAt: Long,
) {
    companion object {
        const val STATUS_PENDING = "PENDING"
        const val STATUS_SENT = "SENT"
        const val STATUS_REJECTED = "REJECTED"
    }
}

package com.alharbah.field.net

/*
 * أسماء الحقول مطابقة لحقول FieldSyncService في المكتبي (يُرسَل JSON عبر Gson).
 */

/** FieldSyncService.SubscriberFieldDTO */
data class SubscriberDto(
    val subscriberId: Int = 0,
    val balance: Double = 0.0,
    val fullName: String? = null,
    val meterNumber: String? = null,
    val address: String? = null,
    val phone: String? = null,
    val previousReading: Double = 0.0,
    val routeId: Int? = null,
)

/** FieldSyncService.ReadingSubmission */
data class ReadingSubmissionDto(
    val subscriberId: Int,
    val currentReading: Double,
    val readingDate: String,
    val collectorUserId: Int? = null,
)

/** FieldSyncService.ReadingResult */
data class ReadingResultDto(
    val subscriberId: Int = 0,
    val success: Boolean = false,
    val message: String? = null,
    val readingId: Int? = null,
)

package com.alharbah.field.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.alharbah.field.data.AppDatabase
import com.alharbah.field.data.Prefs
import com.alharbah.field.data.ReadingEntity
import com.alharbah.field.data.SubscriberEntity
import com.alharbah.field.data.SyncRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.time.LocalDate

class FieldViewModel(app: Application) : AndroidViewModel(app) {

    private val db = AppDatabase.get(app)
    val prefs = Prefs(app)
    private val repo = SyncRepository(db, prefs)

    val subscribers: StateFlow<List<SubscriberEntity>> = db.subscriberDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val readings: StateFlow<List<ReadingEntity>> = db.readingDao().observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val pendingCount: StateFlow<Int> = db.readingDao().observePendingCount()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), 0)

    private val _status = MutableStateFlow("")
    val status: StateFlow<String> = _status.asStateFlow()

    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()

    /** تنزيل المشتركين ثم رفع القراءات المعلّقة. */
    fun sync() = runTask("جارٍ المزامنة...") {
        val pulled = repo.pullSubscribers()
        val report = repo.pushPending()
        buildString {
            append("تم تحميل $pulled مشترك. ")
            append("أُرسلت ${report.sent} قراءة")
            if (report.rejected > 0) append("، ورُفضت ${report.rejected} (راجع السبب في قائمة القراءات)")
            append(".")
        }
    }

    fun testConnection() = runTask("جارٍ اختبار الاتصال...") {
        repo.checkConnection()
        "الاتصال بالمكتبي ناجح."
    }

    /**
     * يتحقق من القراءة قبل حفظها محلياً كما يتحقق الخادم: لا تكون أقل من السابقة.
     * يرجع رسالة الخطأ، أو null عند النجاح.
     */
    fun saveReading(subscriber: SubscriberEntity, previous: Double, current: Double, onDone: (String?) -> Unit) {
        if (current < previous) {
            onDone("القراءة الحالية (${fmt(current)}) أقل من السابقة (${fmt(previous)}).")
            return
        }
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                db.readingDao().insert(
                    ReadingEntity(
                        subscriberId = subscriber.subscriberId,
                        previousReading = previous,
                        currentReading = current,
                        readingDate = LocalDate.now().toString(),
                        collectorUserId = prefs.collectorUserId,
                        createdAt = System.currentTimeMillis(),
                    )
                )
            }
            _status.value = "تم حفظ القراءة محلياً، وستُرفع عند المزامنة."
            onDone(null)
        }
    }

    /** السابقة الفعلية للمشترك: آخر قراءة محلية غير مرفوضة، وإلا قيمة الخادم. */
    suspend fun previousFor(subscriber: SubscriberEntity): Double = withContext(Dispatchers.IO) {
        db.readingDao().latestFor(subscriber.subscriberId)?.currentReading ?: subscriber.previousReading
    }

    fun saveSettings(host: String, port: Int, apiKey: String, routeId: Int?, collectorId: Int?) {
        prefs.host = host
        prefs.port = port
        prefs.apiKey = apiKey
        prefs.routeId = routeId
        prefs.collectorUserId = collectorId
        _status.value = "تم حفظ الإعدادات."
    }

    private fun runTask(label: String, block: suspend () -> String) {
        if (_busy.value) return
        viewModelScope.launch {
            _busy.value = true
            _status.value = label
            _status.value = try {
                block()
            } catch (e: Exception) {
                "فشل: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                _busy.value = false
            }
        }
    }

    private fun fmt(v: Double): String =
        if (v % 1.0 == 0.0) v.toLong().toString() else String.format("%.2f", v)
}

package com.alharbah.field.data

import android.content.Context

/**
 * إعدادات الاتصال بخادم المكتبي.
 *  - الشبكة المحلية: host = عنوان IP للمكتبي (يظهر في شاشة تحكم المزامنة).
 *  - كابل USB: host = 127.0.0.1 مع تشغيل الأمر: adb reverse tcp:8765 tcp:8765
 */
class Prefs(context: Context) {

    private val sp = context.getSharedPreferences("field_prefs", Context.MODE_PRIVATE)

    var host: String
        get() = sp.getString("host", DEFAULT_HOST) ?: DEFAULT_HOST
        set(value) { sp.edit().putString("host", value.trim()).apply() }

    var port: Int
        get() = sp.getInt("port", DEFAULT_PORT)
        set(value) { sp.edit().putInt("port", value).apply() }

    var apiKey: String
        get() = sp.getString("apiKey", "") ?: ""
        set(value) { sp.edit().putString("apiKey", value.trim()).apply() }

    /** null = كل خطوط السير. */
    var routeId: Int?
        get() = sp.getInt("routeId", -1).takeIf { it >= 0 }
        set(value) { sp.edit().putInt("routeId", value ?: -1).apply() }

    /** معرّف المحصّل في المكتبي (users.user_id)، يُسجَّل مع كل قراءة. */
    var collectorUserId: Int?
        get() = sp.getInt("collector", -1).takeIf { it >= 0 }
        set(value) { sp.edit().putInt("collector", value ?: -1).apply() }

    val baseUrl: String get() = "http://$host:$port"

    companion object {
        const val DEFAULT_HOST = "127.0.0.1"
        const val DEFAULT_PORT = 8765
    }

    /** عنوان الطابعة البلوتوث (MAC) المختارة من الأجهزة المقترنة. */
    var printerAddress: String?
        get() = sp.getString("printer_addr", null)
        set(v) = sp.edit().putString("printer_addr", v).apply()

    /** اسم الطابعة للعرض في الإعدادات. */
    var printerName: String?
        get() = sp.getString("printer_name", null)
        set(v) = sp.edit().putString("printer_name", v).apply()

    /** عرض ورق الطابعة بالملليمتر: 58 أو 80. */
    var paperWidthMm: Int
        get() = sp.getInt("paper_mm", 58)
        set(v) = sp.edit().putInt("paper_mm", v).apply()
}

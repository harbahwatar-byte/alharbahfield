package com.alharbah.field.print

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint

/**
 * يرسم إيصال القراءة كصورة بالعربية (يتولى أندرويد تشكيل الحروف والاتجاه)،
 * ثم تُرسل الصورة للطابعة الحرارية. هذا يتجنب مشكلات ترميز الطابعات للعربية.
 */
object ReceiptRenderer {

    /** السطور: النص وهل هو عريض. عرض الصورة بالنقاط (384 لورق 58 ملم، 576 لورق 80 ملم). */
    fun render(lines: List<Pair<String, Boolean>>, widthPx: Int): Bitmap {
        val normal = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.BLACK
            textSize = 26f
            typeface = Typeface.DEFAULT
        }
        val bold = TextPaint(normal).apply {
            textSize = 30f
            typeface = Typeface.DEFAULT_BOLD
        }
        val pad = 14
        val innerWidth = widthPx - pad * 2
        val layouts = lines.map { (text, isBold) ->
            StaticLayout.Builder.obtain(text, 0, text.length, if (isBold) bold else normal, innerWidth)
                .setAlignment(Layout.Alignment.ALIGN_NORMAL)
                .setTextDirection(TextDirectionHeuristics.RTL)
                .setIncludePad(false)
                .build()
        }
        val height = layouts.sumOf { it.height } + pad * 2
        val bitmap = Bitmap.createBitmap(widthPx, height.coerceAtLeast(pad * 2), Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)
        var y = pad
        for (layout in layouts) {
            canvas.save()
            canvas.translate(pad.toFloat(), y.toFloat())
            layout.draw(canvas)
            canvas.restore()
            y += layout.height
        }
        return bitmap
    }
}

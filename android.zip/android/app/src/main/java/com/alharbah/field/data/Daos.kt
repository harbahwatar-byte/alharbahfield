package com.alharbah.field.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
abstract class SubscriberDao {
    @Query("SELECT * FROM subscribers ORDER BY routeId, fullName")
    abstract fun observeAll(): Flow<List<SubscriberEntity>>

    @Query("SELECT * FROM subscribers WHERE subscriberId = :id")
    abstract suspend fun getById(id: Int): SubscriberEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    abstract suspend fun insertAll(items: List<SubscriberEntity>)

    @Query("DELETE FROM subscribers")
    abstract suspend fun clear()

    /** يستبدل قائمة المشتركين كاملة بما أرسله الخادم في عملية واحدة. */
    @Transaction
    open suspend fun replaceAll(items: List<SubscriberEntity>) {
        clear()
        insertAll(items)
    }
}

@Dao
interface ReadingDao {
    @Insert
    suspend fun insert(reading: ReadingEntity): Long

    @Query("SELECT * FROM readings ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<ReadingEntity>>

    @Query("SELECT COUNT(*) FROM readings WHERE status = 'PENDING'")
    fun observePendingCount(): Flow<Int>

    @Query("SELECT * FROM readings WHERE status = 'PENDING' ORDER BY localId")
    suspend fun pending(): List<ReadingEntity>

    /** آخر قراءة غير مرفوضة للمشترك (المحلية منها)، وهي السابقة عند إدخال قراءة جديدة. */
    @Query("SELECT * FROM readings WHERE subscriberId = :subscriberId AND status != 'REJECTED' ORDER BY localId DESC LIMIT 1")
    suspend fun latestFor(subscriberId: Int): ReadingEntity?

    @Query("UPDATE readings SET status = :status, message = :message, serverReadingId = :serverId WHERE localId = :localId")
    suspend fun updateResult(localId: Long, status: String, message: String?, serverId: Int?)
}

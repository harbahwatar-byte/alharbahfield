package com.alharbah.field.data

import com.alharbah.field.net.ReadingSubmissionDto
import com.alharbah.field.net.SubscriberDto
import com.alharbah.field.net.SyncClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class PushReport(val total: Int, val sent: Int, val rejected: Int)

/**
 * يربط قاعدة Room بخادم المكتبي:
 *  - pullSubscribers: ينزّل المشتركين حسب خط السير المختار ويستبدل النسخة المحلية.
 *  - pushPending: يرفع القراءات المعلّقة. ما أكّده الخادم يصبح SENT، والمرفوض REJECTED مع سببه.
 *    القراءة التي لم يُرجع الخادم نتيجتها تبقى PENDING للمحاولة القادمة.
 */
class SyncRepository(private val db: AppDatabase, private val prefs: Prefs) {

    private val subscribers = db.subscriberDao()
    private val readings = db.readingDao()

    private fun client() = SyncClient(prefs.baseUrl, prefs.apiKey)

    suspend fun checkConnection() = withContext(Dispatchers.IO) {
        client().checkConnection()
    }

    suspend fun pullSubscribers(): Int = withContext(Dispatchers.IO) {
        val list = client().fetchSubscribers(prefs.routeId)
        subscribers.replaceAll(list.map { it.toEntity() })
        list.size
    }

    suspend fun pushPending(): PushReport = withContext(Dispatchers.IO) {
        val pending = readings.pending()
        if (pending.isEmpty()) return@withContext PushReport(0, 0, 0)

        val payload = pending.map {
            ReadingSubmissionDto(
                subscriberId = it.subscriberId,
                currentReading = it.currentReading,
                readingDate = it.readingDate,
                collectorUserId = it.collectorUserId,
            )
        }
        val results = client().pushReadings(payload)

        var sent = 0
        var rejected = 0
        pending.forEachIndexed { index, local ->
            val res = results.getOrNull(index) ?: return@forEachIndexed
            if (res.success) {
                readings.updateResult(local.localId, ReadingEntity.STATUS_SENT, res.message, res.readingId)
                sent++
            } else {
                readings.updateResult(local.localId, ReadingEntity.STATUS_REJECTED, res.message, null)
                rejected++
            }
        }
        PushReport(total = pending.size, sent = sent, rejected = rejected)
    }

    private fun SubscriberDto.toEntity() = SubscriberEntity(
        subscriberId = subscriberId,
        fullName = fullName ?: "",
        meterNumber = meterNumber,
        address = address,
        phone = phone,
        routeId = routeId,
        balance = balance,
        previousReading = previousReading,
    )
}

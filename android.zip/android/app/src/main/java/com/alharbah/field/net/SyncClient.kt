package com.alharbah.field.net

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

/** استجابة خطأ من الخادم (HTTP غير 2xx). */
class SyncException(val code: Int, message: String) : Exception(message)

/**
 * عميل HTTP لخادم المزامنة في المكتبي (SyncServer، المنفذ 8765).
 * كل طلب يحمل ترويسة X-Api-Key كما يتطلب الخادم.
 */
class SyncClient(private val baseUrl: String, private val apiKey: String) {

    private val http = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val gson = Gson()

    private fun request(path: String): Request.Builder =
        Request.Builder()
            .url(baseUrl.trimEnd('/') + path)
            .header("X-Api-Key", apiKey)

    /** يتحقق أن الخادم يعمل ومفتاح الـ API صحيح. يرمي SyncException عند الفشل. */
    fun checkConnection() {
        execute(request("/api/health").get().build()) { }
    }

    fun fetchSubscribers(routeId: Int?): List<SubscriberDto> {
        val path = if (routeId != null) "/api/subscribers?routeId=$routeId" else "/api/subscribers"
        val type = object : TypeToken<List<SubscriberDto>>() {}.type
        return execute(request(path).get().build()) { body ->
            gson.fromJson<List<SubscriberDto>>(body, type)
        }
    }

    /** يرسل دفعة قراءات، ويعيد نتيجة لكل قراءة بنفس ترتيب الإرسال. */
    fun pushReadings(items: List<ReadingSubmissionDto>): List<ReadingResultDto> {
        val json = gson.toJson(items)
        val body = json.toRequestBody("application/json; charset=utf-8".toMediaType())
        val type = object : TypeToken<List<ReadingResultDto>>() {}.type
        return execute(request("/api/readings").post(body).build()) { text ->
            gson.fromJson<List<ReadingResultDto>>(text, type)
        }
    }

    private fun <T> execute(req: Request, parse: (String) -> T): T {
        http.newCall(req).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                throw SyncException(resp.code, extractError(text, resp.code))
            }
            return parse(text)
        }
    }

    /** الخادم يرجع {"error":"..."} عند الخطأ، ونستخرج الرسالة إن وُجدت. */
    private fun extractError(text: String, code: Int): String = try {
        val map = gson.fromJson(text, Map::class.java)
        (map?.get("error") as? String) ?: "خطأ من الخادم (HTTP $code)"
    } catch (e: Exception) {
        "خطأ من الخادم (HTTP $code)"
    }
}

package com.alharbah.field.print

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.graphics.Bitmap
import android.graphics.Color
import java.io.ByteArrayOutputStream
import java.util.UUID

/**
 * طباعة حرارية عبر البلوتوث الكلاسيكي (SPP) بأوامر ESC/POS الشائعة.
 * تُستدعى من خيط خلفية (Dispatchers.IO). عرض الورق من الإعدادات: 58 أو 80 ملم.
 */
object PrinterService {

    private val SPP: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    /** الأجهزة المقترنة مسبقاً في الهاتف (تُعرض للمستخدم لاختيار الطابعة). */
    @SuppressLint("MissingPermission")
    fun pairedPrinters(): List<Pair<String, String>> {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return emptyList()
        return adapter.bondedDevices.map { (it.name ?: "جهاز") to it.address }
    }

    /** يطبع الصورة. يرمي استثناءً عند فشل الاتصال أو الطباعة. */
    @SuppressLint("MissingPermission")
    fun printBitmap(address: String, bitmap: Bitmap, paperMm: Int) {
        val adapter = BluetoothAdapter.getDefaultAdapter()
            ?: throw IllegalStateException("البلوتوث غير مدعوم على هذا الجهاز")
        adapter.cancelDiscovery()
        val device = adapter.getRemoteDevice(address)
        val socket = device.createRfcommSocketToServiceRecord(SPP)
        socket.connect()
        try {
            val out = socket.outputStream
            out.write(byteArrayOf(0x1B, 0x40))                 // ESC @ : تهيئة الطابعة
            out.write(raster(bitmap, paperMm))                  // GS v 0 : طباعة الصورة
            out.write(byteArrayOf(0x1B, 0x64, 0x04))            // ESC d 4 : تغذية 4 أسطر
            out.write(byteArrayOf(0x1D, 0x56, 0x42, 0x00))      // GS V B 0 : قطع جزئي للورق
            out.flush()
            Thread.sleep(600)
        } finally {
            socket.close()
        }
    }

    /** يحوّل الصورة إلى بتات أبيض وأسود بأوامر الصور الخام (GS v 0). */
    fun raster(source: Bitmap, paperMm: Int): ByteArray {
        val dots = if (paperMm >= 80) 576 else 384
        val scaledHeight = (source.height.toLong() * dots / source.width).toInt().coerceAtLeast(1)
        val img = Bitmap.createScaledBitmap(source, dots, scaledHeight, true)
        val bytesPerRow = dots / 8
        val h = img.height
        val pixels = IntArray(dots * h)
        img.getPixels(pixels, 0, dots, 0, 0, dots, h)

        val out = ByteArrayOutputStream()
        out.write(byteArrayOf(0x1D, 0x76, 0x30, 0x00))
        out.write(bytesPerRow and 0xFF)
        out.write((bytesPerRow shr 8) and 0xFF)
        out.write(h and 0xFF)
        out.write((h shr 8) and 0xFF)
        for (y in 0 until h) {
            for (xb in 0 until bytesPerRow) {
                var byte = 0
                for (bit in 0 until 8) {
                    val p = pixels[y * dots + xb * 8 + bit]
                    val gray = 0.3 * Color.red(p) + 0.59 * Color.green(p) + 0.11 * Color.blue(p)
                    if (gray < 128) byte = byte or (0x80 shr bit)
                }
                out.write(byte)
            }
        }
        return out.toByteArray()
    }
}

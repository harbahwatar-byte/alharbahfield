package com.alharbah.field.print

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** يطبع إيصال القراءة بعد حفظها، في خيط خلفي. يتجاهل الأمر بصمت إن لم تُضبط طابعة. */
object ReadingPrinter {

    fun printReading(
        context: Context,
        address: String?,
        paperMm: Int,
        name: String,
        meter: String?,
        previous: Double,
        current: Double,
        balance: Double,
    ) {
        if (address.isNullOrBlank()) return
        val date = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.US).format(Date())
        val consumption = current - previous
        val lines = listOf(
            "إيصال قراءة" to true,
            "المشترك: $name" to false,
            "العداد: ${meter ?: "-"}" to false,
            "السابقة: ${fmt(previous)}" to false,
            "الحالية: ${fmt(current)}" to false,
            "الاستهلاك: ${fmt(consumption)} م3" to true,
            "المستحق: ${fmt(balance)}" to false,
            "التاريخ: $date" to false,
        )
        val width = if (paperMm >= 80) 576 else 384
        val appContext = context.applicationContext
        Thread {
            try {
                val bitmap = ReceiptRenderer.render(lines, width)
                PrinterService.printBitmap(address, bitmap, paperMm)
            } catch (e: Exception) {
                Handler(Looper.getMainLooper()).post {
                    Toast.makeText(appContext, "تعذّرت الطباعة: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun fmt(v: Double): String = String.format(Locale.US, "%.2f", v)
}

package com.alharbah.field.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.alharbah.field.data.ReadingEntity
import com.alharbah.field.data.SubscriberEntity

/** الشاشات: قائمة المشتركين، إدخال القراءة، قائمة القراءات والمزامنة، الإعدادات. */
sealed interface Page {
    data object Subscribers : Page
    data class Reading(val subscriberId: Int) : Page
    data object Readings : Page
    data object Settings : Page
}

@Composable
fun FieldApp(vm: FieldViewModel = viewModel()) {
    var page by remember { mutableStateOf<Page>(Page.Subscribers) }
    val back: () -> Unit = { page = Page.Subscribers }

    when (val p = page) {
        Page.Subscribers -> SubscribersScreen(
            vm = vm,
            onOpen = { page = Page.Reading(it) },
            onReadings = { page = Page.Readings },
            onSettings = { page = Page.Settings },
        )
        is Page.Reading -> ReadingScreen(vm = vm, subscriberId = p.subscriberId, onBack = back)
        Page.Readings -> ReadingsScreen(vm = vm, onBack = back)
        Page.Settings -> SettingsScreen(vm = vm, onBack = back)
    }
}

// ───────────────────────── قائمة المشتركين ─────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SubscribersScreen(
    vm: FieldViewModel,
    onOpen: (Int) -> Unit,
    onReadings: () -> Unit,
    onSettings: () -> Unit,
) {
    val subscribers by vm.subscribers.collectAsState()
    val pending by vm.pendingCount.collectAsState()
    val status by vm.status.collectAsState()
    val busy by vm.busy.collectAsState()
    var query by remember { mutableStateOf("") }

    val shown = subscribers.filter {
        query.isBlank() ||
            it.fullName.contains(query, ignoreCase = true) ||
            (it.meterNumber?.contains(query, ignoreCase = true) == true)
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("المشتركون (${subscribers.size})") },
                actions = {
                    TextButtonLike("القراءات ($pending)", onReadings)
                    IconButton(onClick = onSettings) { Text("⚙") }
                },
            )
        },
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("بحث بالاسم أو رقم العداد") },
                    singleLine = true,
                    modifier = Modifier.weight(1f),
                )
                Button(
                    onClick = { vm.sync() },
                    enabled = !busy,
                    modifier = Modifier.padding(start = 8.dp),
                ) { Text("مزامنة") }
            }
            if (busy) CircularProgressIndicator(modifier = Modifier.padding(top = 8.dp))
            if (status.isNotBlank()) {
                Text(status, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(vertical = 6.dp))
            }

            if (subscribers.isEmpty()) {
                Text(
                    "لا يوجد مشتركون محفوظون على الجهاز.\nاضغط «مزامنة» بعد ضبط الإعدادات.",
                    modifier = Modifier.padding(top = 24.dp),
                )
            }

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                items(shown, key = { it.subscriberId }) { s ->
                    SubscriberRow(s, onClick = { onOpen(s.subscriberId) })
                }
            }
        }
    }
}

@Composable
private fun SubscriberRow(s: SubscriberEntity, onClick: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(s.fullName, fontWeight = FontWeight.Bold)
            Text("عداد: ${s.meterNumber ?: "-"}   •   السابقة: ${num(s.previousReading)}")
            Text("المستحق: ${num(s.balance)}", style = MaterialTheme.typography.bodySmall)
        }
    }
}

// ───────────────────────── إدخال القراءة ─────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReadingScreen(vm: FieldViewModel, subscriberId: Int, onBack: () -> Unit) {
    val subscribers by vm.subscribers.collectAsState()
    val subscriber = subscribers.find { it.subscriberId == subscriberId }
    val ctx = LocalContext.current
    var scanning by remember { mutableStateOf(false) }

    var previous by remember { mutableStateOf<Double?>(null) }
    var input by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var saving by remember { mutableStateOf(false) }

    LaunchedEffect(subscriber?.subscriberId) {
        subscriber?.let { previous = vm.previousFor(it) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(subscriber?.fullName ?: "مشترك") },
                navigationIcon = { IconButton(onClick = onBack) { Text("→") } },
            )
        },
    ) { padding ->
        if (subscriber == null) {
            Text("المشترك غير موجود على الجهاز.", modifier = Modifier.padding(padding).padding(16.dp))
            return@Scaffold
        }
        if (scanning) {
            MeterScanScreen(
                onResult = { input = it; error = null; scanning = false },
                onCancel = { scanning = false },
            )
            return@Scaffold
        }
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp)) {
            Text("العداد: ${subscriber.meterNumber ?: "-"}")
            Text("العنوان: ${subscriber.address ?: "-"}")
            Text("المستحق: ${num(subscriber.balance)}")
            Spacer(Modifier.height(16.dp))
            Text("القراءة السابقة: ${previous?.let { num(it) } ?: "..."}", fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))

            OutlinedTextField(
                value = input,
                onValueChange = { input = it; error = null },
                label = { Text("القراءة الحالية") },
                singleLine = true,
                isError = error != null,
                modifier = Modifier.fillMaxWidth(),
            )
            error?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 6.dp)) }
            OutlinedButton(onClick = { scanning = true }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
                Text("📷 قراءة العداد بالكاميرا")
            }

            Spacer(Modifier.height(16.dp))
            Button(
                enabled = !saving && previous != null && input.isNotBlank(),
                onClick = {
                    val value = input.toDoubleOrNull()
                    val prev = previous
                    when {
                        value == null -> error = "أدخل رقماً صحيحاً."
                        prev == null -> error = "جارٍ تحميل القراءة السابقة..."
                        else -> {
                            saving = true
                            vm.saveReading(subscriber, prev, value) { err ->
                                saving = false
                                if (err == null) {
                                    com.alharbah.field.print.ReadingPrinter.printReading(
                                        ctx, vm.prefs.printerAddress, vm.prefs.paperWidthMm,
                                        subscriber.fullName, subscriber.meterNumber, prev, value, subscriber.balance,
                                    )
                                    onBack()
                                } else error = err
                            }
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("حفظ القراءة") }
        }
    }
}

// ───────────────────────── قائمة القراءات ─────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReadingsScreen(vm: FieldViewModel, onBack: () -> Unit) {
    val readings by vm.readings.collectAsState()
    val subscribers by vm.subscribers.collectAsState()
    val status by vm.status.collectAsState()
    val busy by vm.busy.collectAsState()
    val names = remember(subscribers) { subscribers.associate { it.subscriberId to it.fullName } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("القراءات") },
                navigationIcon = { IconButton(onClick = onBack) { Text("→") } },
            )
        },
    ) { padding ->
        Column(modifier = Modifier.fillMaxSize().padding(padding).padding(12.dp)) {
            Button(onClick = { vm.sync() }, enabled = !busy, modifier = Modifier.fillMaxWidth()) {
                Text("رفع القراءات المعلّقة")
            }
            if (status.isNotBlank()) Text(status, modifier = Modifier.padding(vertical = 6.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
                items(readings, key = { it.localId }) { r ->
                    ReadingRow(r, names[r.subscriberId] ?: "مشترك #${r.subscriberId}")
                }
            }
        }
    }
}

@Composable
private fun ReadingRow(r: ReadingEntity, name: String) {
    val label = when (r.status) {
        ReadingEntity.STATUS_PENDING -> "بانتظار المزامنة"
        ReadingEntity.STATUS_SENT -> "أُرسلت ✓"
        ReadingEntity.STATUS_REJECTED -> "مرفوضة ✗"
        else -> r.status
    }
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(name, fontWeight = FontWeight.Bold)
            Text("${num(r.previousReading)} ← ${num(r.currentReading)}   •   ${r.readingDate}")
            Text(label, style = MaterialTheme.typography.bodySmall)
            r.message?.takeIf { r.status == ReadingEntity.STATUS_REJECTED }?.let {
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

// ───────────────────────── الإعدادات ─────────────────────────

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(vm: FieldViewModel, onBack: () -> Unit) {
    val prefs = vm.prefs
    var host by remember { mutableStateOf(prefs.host) }
    var port by remember { mutableStateOf(prefs.port.toString()) }
    var apiKey by remember { mutableStateOf(prefs.apiKey) }
    var route by remember { mutableStateOf(prefs.routeId?.toString() ?: "") }
    var collector by remember { mutableStateOf(prefs.collectorUserId?.toString() ?: "") }
    val status by vm.status.collectAsState()
    val busy by vm.busy.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("الإعدادات") },
                navigationIcon = { IconButton(onClick = onBack) { Text("→") } },
            )
        },
    ) { padding ->
        Column(
            modifier = Modifier.fillMaxSize().padding(padding).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            OutlinedTextField(host, { host = it }, label = { Text("عنوان المكتبي (IP)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(port, { port = it }, label = { Text("المنفذ") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(apiKey, { apiKey = it }, label = { Text("مفتاح API (من شاشة تحكم المزامنة)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(route, { route = it }, label = { Text("رقم خط السير (فارغ = الكل)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(collector, { collector = it }, label = { Text("رقم المحصّل في المكتبي") }, singleLine = true, modifier = Modifier.fillMaxWidth())

            Button(
                onClick = {
                    vm.saveSettings(
                        host = host.ifBlank { "127.0.0.1" },
                        port = port.toIntOrNull() ?: 8765,
                        apiKey = apiKey,
                        routeId = route.toIntOrNull(),
                        collectorId = collector.toIntOrNull(),
                    )
                },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("حفظ الإعدادات") }

            OutlinedButton(
                onClick = { vm.testConnection() },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth(),
            ) { Text("اختبار الاتصال") }

            OutlinedButton(
                onClick = { host = "127.0.0.1"; port = "8765" },
                modifier = Modifier.fillMaxWidth(),
            ) { Text("وضع USB (127.0.0.1 : 8765) ثم احفظ") }

            PrinterSection(prefs = vm.prefs)
            if (status.isNotBlank()) Text(status)
            Text(
                "الشبكة المحلية: ضع IP المكتبي. كابل USB: ضع 127.0.0.1 ونفّذ على الحاسوب:\nadb reverse tcp:8765 tcp:8765",
                style = MaterialTheme.typography.bodySmall,
            )
        }
    }
}

// ───────────────────────── أدوات ─────────────────────────

@Composable
private fun TextButtonLike(text: String, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = Modifier.padding(end = 4.dp)) { Text(text) }
}

private fun num(v: Double): String =
    if (v % 1.0 == 0.0) v.toLong().toString() else String.format("%.2f", v)

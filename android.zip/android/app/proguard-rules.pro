# قواعد ProGuard (غير مفعّلة حالياً: isMinifyEnabled = false)
-keep class com.alharbah.field.net.** { *; }
